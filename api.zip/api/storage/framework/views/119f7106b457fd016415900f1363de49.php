

<?php $__env->startSection('contenido'); ?>
<div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">Seeaders</h3>

              <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#editarC">Agregar</button>
            </div>
              <div class="col-sm-6">
            
              </div>
            </div>
            <!--end::Row-->
          </div>
           <!--end::Container-->
        </div>
        
        <div class="app-content">
          <div class="row">
<div class="col-4">
  <h1>Marcas</h1>
<table class="table">
  
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombres</th>
     </tr>
  </thead>
  <?php $__currentLoopData = $Marca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MARCA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
    <tr>
      <th scope="row"><?php echo e($MARCA->id); ?></th>
      <td><?php echo e($MARCA->name); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
</div>

<!-- Modal -->
<div class="modal fade" id="editarC" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Editar Categoria</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="mb-3">
        <form class="form-floating mb-3" enctype="multipart/form-data" method="post" action="<?php echo e(url('admin/products')); ?>">
<?php echo csrf_field(); ?>
<?php echo method_field('POST'); ?>
  <label for="formGroupExampleInput" class="form-label">Categoria</label>
  <input type="text" class="form-control" name="nombre" id="formGroupExampleInput" placeholder="Example input placeholder">
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit " class="btn btn-primary">Save changes</button>
      </form>
      </div>
    </div>
  </div>
</div>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\axelf\OneDrive\Escritorio\Proyecto1\api\resources\views/admin/marca.blade.php ENDPATH**/ ?>