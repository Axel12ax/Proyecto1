

<?php $__env->startSection('contenido'); ?>
<div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">Usuarios</h3></div>
              <div class="col-sm-6">
              <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Agregar Usuario
</button>

              </div>
            </div>
            <!--end::Row-->
          </div>
           <!--end::Container-->
        </div>

        <!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Agregar Usuario</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form class="row g-3" action="<?php echo e(url('admin/users')); ?>" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>
      <div class="modal-body">
      <div class="form-floating mb-3" enctype="multipart/form-data" method="post" action="<?php echo e(url('admin/users')); ?>">
  <input name="name" type="text" class="form-control" id="floatingInput" placeholder="name@example.com">
  <label for="floatingInput">Nombres</label>
</div>
      <div class="form-floating mb-3">
  <input name="email" type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
  <label for="floatingInput">Email address</label>
</div>
<div class="form-floating mb-3">
  <input name="password" type="password" class="form-control" id="floatingPassword" placeholder="Password">
  <label for="floatingPassword">Password</label>
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </form>
      </div>
    </div>
  </div>
</div>
        <div class="app-content">
        <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">nombre</th>
      <th scope="col">Correo</th>
      <th scope="col">Modificar</th>
    
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($user->id); ?></td>
      <td><?php echo e($user->name); ?></td>
      <td><?php echo e($user->email); ?></td>
      <td>
        <div class="d-grid gap-2 d-md-block">
   

        <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#exampleModal1">
  Editar Usuario
</button>

  <form action="<?php echo e(url('admin/users/'.$user->id)); ?>" method="POST"  style="display:inline;" onsubmit="return confirm('¿Estás seguro de eliminar este Usuario?');">
  <?php echo csrf_field(); ?>
  <?php echo method_field('DELETE'); ?>
  
  <button class="btn btn-outline-danger" type="submit">Eliminar</button>
</div>
</form>
</td>  
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<!-- Modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Agregar Titulo</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form class="row g-3" action="<?php echo e(url('admin/users/'.$user->id)); ?>" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
      <div class="modal-body">
      <div class="form-floating mb-3" enctype="multipart/form-data" method="post" action="<?php echo e(url('admin/users')); ?>">
  <input name="name" type="text" value="<?php echo e($user->name); ?>" class="form-control" id="floatingInput" placeholder="name@example.com">
  <label for="floatingInput">Nombres</label>
</div>
      <div class="form-floating mb-3">
  <input name="email" type="email" value="<?php echo e($user->email); ?>" class="form-control" id="floatingInput" placeholder="name@example.com">
  <label for="floatingInput">Email address</label>
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
      </form>
      </div>
    </div>
  </div>
</div>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\axelf\OneDrive\Escritorio\Proyecto1\api\resources\views/admin/users.blade.php ENDPATH**/ ?>