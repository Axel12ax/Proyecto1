

<?php $__env->startSection('contenido'); ?>
<div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">Seeaders</h3>

              <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#editarC">Agregar</button>
            </div>
              <div class="col-sm-6">
            
              </div>
            </div>
            <!--end::Row-->
          </div>
           <!--end::Container-->
        </div>
        
        <div class="app-content">
          <div class="row">
        <div class="col-4">
          <h1>Categorias</h1> 
        <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombres</th>
      <th scope="col">Modificar</th>
     </tr>
  </thead>
  <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CATE): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
    <tr>
      <th scope="row"><?php echo e($CATE->id); ?></th>
      <td><?php echo e($CATE->name); ?></td>
      <td>
   
      <button type="button" class="btn btn-outline-danger" >Eliminar</button>


      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>

</div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\axelf\OneDrive\Escritorio\Proyecto1\api\resources\views/admin/products.blade.php ENDPATH**/ ?>