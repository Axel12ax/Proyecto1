

<?php $__env->startSection('contenido'); ?>
<div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">Vehiculos</h3></div>
              <div class="col-sm-6">
              <button type="submit" class="btn btn-primary "  data-bs-toggle="modal" data-bs-target="#staticBackdrop">
              Agregar Vehiculo
              </button>


              </div>
            </div>
            <!--end::Row-->
          </div>
           <!--end::Container-->
        </div>
        <div class="app-content m-4">
          <!-- Button trigger modal -->
           


<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Agregar Vehiculo</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form class="row g-3" action="<?php echo e(url('admin/vehiculo')); ?>" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>
  <div class="col-md-6">
    <label for="" class="form-label">Modelo</label>
    <input  name="modelo" type="text" class="form-control" id="inputEmail4">
  </div>
  <div class="col-md-6">
    <label for="" class="form-label">Numero de Serie</label>
    <input name="NSerie" type="text" class="form-control" id="inputPassword4">
  </div>
  <div class="col-12">
    <label for="" class="form-label">Año</label>
    <input name="año" type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
  </div>
  <div class="col-12">
    <label for="" class="form-label">color</label>
    <input name="color" type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
  </div>
  <label for="" class="form-label">Imagen</label>
  <div class="input-group">
  <input name="imagen" type="file" class="form-control" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
  <button nclass="btn btn-outline-secondary" type="button" id="inputGroupFileAddon04">Button</button>
</div>
  <div class="col-md-6">
    <label for="" class="form-label">Kilometros</label>
    <input name="kilometros" type="text" class="form-control" id="inputCity">
  </div>
  <div class="col-md-4">
   
    <label for="" class="form-label">Marcas</label>
    <select name="id_categoria" id="" class="form-select">
    <?php $__currentLoopData = $CATEGORIA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($Categoria->id); ?>" ><?php echo e($Categoria->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <option>...</option>
    </select>
  </div>
  <div class="col-md-4">
   
    <label for="" class="form-label">Marcas</label>
    <select name="id_marca" id="" class="form-select">
    <?php $__currentLoopData = $MARCA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($marca->id); ?>" ><?php echo e($marca->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <option>...</option>
    </select>
  </div>
  <div class="col-md-2">
    <label for="" class="form-label">Precio</label>
    <input name="precio" type="text" class="form-control" id="inputZip">
  </div>

  <div class="col-12">
    <label for="" class="form-label">Descripcion</label>
    <input  name="descripcion" type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
  </div>
  <div class="col-12">
  </div>
  <div class="col-12">
    <button type="submit" class="btn btn-primary">Agregar Vehiculo</button>
  </div>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Understood</button>
      </div>
    </div>
  </div>
</div>
         
        <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Usuario</th>
      <th scope="col">Numero de Serie</th>
      <th scope="col">Marca</th>
      <th scope="col">Modelo</th>
      <th scope="col">Categoria</th>
      <th scope="col">Color</th>
      <th scope="col">Año</th>
      <th scope="col">Imagen</th>
      <th scope="col">Precio</th>
      <th scope="col">Kilometros</th>
      <th scope="col">Descripcion</th>
      <th scope="col">Modificar</th>
    </tr>
  </thead>
  <tbody>
   <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($ve->id); ?></td>
      <td><?php echo e($ve->user->name); ?></td>
      <td><?php echo e($ve->NSerie); ?>

        
      <td><?php echo e($ve->marca->name); ?></td>
      <td><?php echo e($ve->modelo); ?></td>
      <td><?php echo e($ve->categoria->name); ?></td>
     
      <td><?php echo e($ve->color); ?></td>
      <td><?php echo e($ve->año); ?></td>
      <td>
        <img src="<?php echo e(asset('img_V/'.$ve->img)); ?>" width="70px" alt="">
      </td>
      <td>$ <?php echo e($ve->precio); ?></td>
      <td><?php echo e($ve->kilometros); ?> Km</td>
      <td><?php echo e($ve->descripcion); ?></td>
      <td>
      
                <button type="submit" class="btn btn-outline-secondary "  data-bs-toggle="modal" data-bs-target="#staticBackdrop1">
                Editar
              </button>
                          
  <form action="<?php echo e(url('admin/vehiculo/'.$ve->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('¿Estás seguro de eliminar este vehículo?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
  <button class="btn btn-outline-danger" type="submit">Eliminar</button>
  </form>  
</div></td>  
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<div class="modal fade" id="staticBackdrop1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Editar</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form class="row g-3" action="<?php echo e(url('admin/vehiculo/'.$ve->id)); ?>" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
  <div class="col-md-6">
    <label for="" class="form-label">Modelo</label>
    <input  name="modelo" type="text" value="<?php echo e($ve->modelo); ?>" class="form-control" id="inputEmail4">
  </div>
  <div class="col-md-6">
    <label for="" class="form-label">Numero de Serie</label>
    <input name="NSerie" type="text" value="<?php echo e($ve->NSerie); ?>" class="form-control" id="inputPassword4">
  </div>
  <div class="col-12">
    <label for="" class="form-label">Año</label>
    <input name="año" type="text" value="<?php echo e($ve->año); ?>" class="form-control" id="inputAddress" placeholder="1234 Main St">
  </div>
  <div class="col-12">
    <label for="" class="form-label">color</label>
    <input name="color" type="text" value="<?php echo e($ve->color); ?>" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
  </div>
  <label for="" class="form-label">Imagen</label>
  <div class="input-group">
  <input name="imagen" value="<?php echo e($ve->imagen); ?>" type="file" class="form-control" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
</div>
  <div class="col-md-6">
    <label for="" class="form-label">Kilometros</label>
    <input name="kilometros" value="<?php echo e($ve->kilometros); ?>" type="text" class="form-control" id="inputCity">
  </div>
  <div class="col-md-4">
   
    <label for="" class="form-label">Marcas</label>
    <select name="id_categoria" id="" class="form-select">
    <?php $__currentLoopData = $CATEGORIA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($Categoria->id); ?>" ><?php echo e($Categoria->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <option>...</option>
    </select>
  </div>
  <div class="col-md-4">
   
    <label for="" class="form-label">Marcas</label>
    <select name="id_marca" id="" class="form-select">
    <?php $__currentLoopData = $MARCA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($marca->id); ?>" ><?php echo e($marca->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <option>...</option>
    </select>
  </div>
  <div class="col-md-2">
    <label for="" class="form-label">Precio</label>
    <input name="precio" value="<?php echo e($ve->precio); ?>" type="text" class="form-control" id="inputZip">
  </div>

  <div class="col-12">
    <label for="" class="form-label">Descripcion</label>
    <input  name="descripcion" value="<?php echo e($ve->descripcion); ?>" type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
  </div>
  <div class="col-12">
  </div>
  <div class="col-12">
    <button type="submit" class="btn btn-primary">Editar Vehiculo</button>
  </div>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\axelf\OneDrive\Escritorio\Proyecto1\api\resources\views/admin/vehiculo.blade.php ENDPATH**/ ?>